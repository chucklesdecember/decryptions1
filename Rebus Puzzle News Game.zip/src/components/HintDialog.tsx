import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Button } from './ui/button';
import { Lightbulb } from 'lucide-react';

interface HintDialogProps {
  hints: string[];
  usedHints: number;
  onUseHint: () => void;
}

export function HintDialog({ hints, usedHints, onUseHint }: HintDialogProps) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Lightbulb className="w-4 h-4" />
          Hints ({usedHints}/{hints.length})
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Hints</DialogTitle>
          <DialogDescription>
            Get helpful hints to solve the puzzle. Use them wisely!
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          {hints.slice(0, usedHints).map((hint, index) => (
            <div key={index} className="p-3 bg-accent rounded-lg">
              <p className="text-sm">
                <span className="text-primary mr-2">Hint {index + 1}:</span>
                {hint}
              </p>
            </div>
          ))}
          
          {usedHints < hints.length && (
            <Button onClick={onUseHint} className="w-full">
              Reveal Next Hint ({usedHints + 1}/{hints.length})
            </Button>
          )}
          
          {usedHints === 0 && (
            <p className="text-sm text-muted-foreground text-center">
              Click above to reveal your first hint!
            </p>
          )}
          
          {usedHints === hints.length && (
            <p className="text-sm text-muted-foreground text-center">
              No more hints available. You've got this! 💪
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
