import { useState, useEffect, useRef } from 'react';
import { PuzzleBox } from './PuzzleBox';

interface PuzzleClue {
  type: 'image' | 'text' | 'symbol';
  content: string;
  alt?: string;
}

interface PuzzleWord {
  answer: string;
  clues: PuzzleClue[];
}

interface RebusPuzzleProps {
  words: PuzzleWord[];
  onComplete: () => void;
  isPaused?: boolean;
}

export function RebusPuzzle({ words, onComplete, isPaused = false }: RebusPuzzleProps) {
  const [userInputs, setUserInputs] = useState<string[]>(words.map(() => ''));
  const [correctAnswers, setCorrectAnswers] = useState<boolean[]>(words.map(() => false));
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    const allCorrect = correctAnswers.every((isCorrect) => isCorrect);
    if (allCorrect && correctAnswers.length > 0) {
      onComplete();
    }
  }, [correctAnswers, onComplete]);

  const handleInputChange = (index: number, value: string) => {
    const newInputs = [...userInputs];
    newInputs[index] = value;
    setUserInputs(newInputs);

    const newCorrect = [...correctAnswers];
    const isCorrect = value.toUpperCase() === words[index].answer.toUpperCase();
    newCorrect[index] = isCorrect;
    setCorrectAnswers(newCorrect);

    // Auto-focus next input when current word is correct
    if (isCorrect && index < words.length - 1) {
      // Find next unanswered question
      for (let i = index + 1; i < words.length; i++) {
        if (!newCorrect[i]) {
          setTimeout(() => {
            inputRefs.current[i]?.focus();
          }, 300);
          break;
        }
      }
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-3xl">
      {words.map((word, index) => (
        <PuzzleBox
          key={index}
          ref={(el) => (inputRefs.current[index] = el)}
          clues={word.clues}
          answer={word.answer}
          userInput={userInputs[index]}
          onInputChange={(value) => handleInputChange(index, value)}
          isCorrect={correctAnswers[index]}
          isPaused={isPaused}
        />
      ))}
    </div>
  );
}
