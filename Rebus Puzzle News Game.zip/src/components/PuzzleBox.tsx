import { forwardRef } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Input } from './ui/input';

interface PuzzleClue {
  type: 'image' | 'text' | 'symbol' | 'operator';
  content: string;
  alt?: string;
}

interface PuzzleBoxProps {
  clues: PuzzleClue[];
  answer: string;
  userInput: string;
  onInputChange: (value: string) => void;
  isCorrect: boolean;
  isPaused?: boolean;
}

export const PuzzleBox = forwardRef<HTMLInputElement, PuzzleBoxProps>(
  ({ clues, answer, userInput, onInputChange, isCorrect, isPaused = false }, ref) => {
    return (
      <div className="flex flex-col gap-2">
        {/* Clue Display - Card Style */}
        <div className="bg-white border-2 border-border rounded-xl p-3 min-h-[110px] flex items-center justify-center shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center gap-2 flex-wrap justify-center">
            {clues.map((clue, index) => (
              <div key={index} className="flex items-center gap-1.5">
                {clue.type === 'image' && (
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted flex items-center justify-center shadow-sm border border-border">
                    <ImageWithFallback
                      src={clue.content}
                      alt={clue.alt || 'puzzle clue'}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                {clue.type === 'text' && (
                  <span className="px-2.5 py-1.5 bg-white border border-border text-foreground rounded-lg shadow-sm min-w-[2.5rem] text-center">
                    {clue.content}
                  </span>
                )}
                {clue.type === 'operator' && (
                  <span className="text-foreground mx-0.5">
                    {clue.content}
                  </span>
                )}
                {clue.type === 'symbol' && (
                  <span className="text-2xl">{clue.content}</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Answer Input */}
        <Input
          ref={ref}
          type="text"
          value={userInput}
          onChange={(e) => onInputChange(e.target.value.toUpperCase())}
          placeholder="Type your answer..."
          className={`text-center uppercase h-9 border-2 rounded-lg transition-all ${
            isCorrect
              ? 'bg-green-50 border-green-500 text-green-700 shadow-sm'
              : userInput && !isCorrect && userInput.length === answer.length
              ? 'bg-red-50 border-red-500 text-red-700'
              : 'bg-white border-border hover:border-primary/50 focus:border-primary'
          }`}
          disabled={isCorrect || isPaused}
        />
      </div>
    );
  }
);

PuzzleBox.displayName = 'PuzzleBox';
