import { useState, useCallback } from "react";
import { RebusPuzzle } from "./components/RebusPuzzle";
import { Timer } from "./components/Timer";
import { HintDialog } from "./components/HintDialog";
import { InstructionsDialog } from "./components/InstructionsDialog";
import { ShareDialog } from "./components/ShareDialog";
import { Button } from "./components/ui/button";
import { Pause, Play } from "lucide-react";
import { Toaster } from "./components/ui/sonner";

// Mock puzzle data - "ISRAELI HOSTAGES FREED FROM GAZA"
const puzzleData = {
  headline: "Israeli Hostages Freed From Gaza",
  date: "October 13, 2025",
  category: "World News",
  words: [
    {
      answer: "ISRAELI",
      clues: [
        { type: "operator" as const, content: "(" },
        {
          type: "image" as const,
          content:
            "https://images.unsplash.com/photo-1606326608690-4e0281b1e588?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjR8fHF1aXp8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&q=60&w=900",
          alt: "Quiz",
        },
        { type: "operator" as const, content: "- QU ) + (" },
        {
          type: "image" as const,
          content:
            "https://images.unsplash.com/photo-1531129915305-9e84bb5a4b15?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8dHJhaWx8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&q=60&w=900",
          alt: "Trail",
        },
        { type: "operator" as const, content: "-" },
        {
          type: "image" as const,
          content:
            "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTEhISFhUVFRUXFhcWFRUVFhgSFxYWFxUVFRUYHSggGBolHRUWITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lHyUtLS0tLS0tLy0rLS0uLS0tLS0tLS0tLy0tLS0tLS0uLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAwQCBQYBB//EAEkQAAIBAgIGBQgGBwUJAQAAAAABAgMRBCEFEjFBUWEGcYGRoQcTIjJCUrHBcoKS0eHwFCMzQ1NisnOio8LxFhc0RZPD0tPjFf/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAA0EQEAAgIABAMFBwQDAQEAAAAAAQIDEQQSITETQVEUYZGh8AUiMlJxgdEjQrHBM+HxFST/2gAMAwEAAhEDEQA/APuIAAAAAAAAAAAAAAAAAAAAPHKwHqAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8crAeOXHICKVfdFFdp0ypQe17SYhCUkAAAAAAAAAAAAAAAAAAAAAAAAAAAidS+zZvf3EbETq29Xve0rtLBJt8QJoULZvuJiDbJzfGPeTsexqPeu1ZjaEhIAAAAAAAAAAAAAAAAAAAAAAAAEVV3y3b3yIkVqk75LYUmdpZUqVyYgWoxS2F0KtSbf4FJlLGEW9hA9hJp5EwLkWXQ9AAAAAAAAAAAAAAAAAAAAAAAAIMTKytxK2TCClC7KxCV2KsaKvJwvvZAxVNLYNCKh838SIS8rrfzaEkJ1kl+eslDMkAAAAAAAAAAAAAAAAAAAAAAAFPEyz6jOyYTYaFlfiWrBKYsgAjqzsmyJkRU8orvIjsllTjdLv+4QJrFkPQAAAAAAAAAAAAAAAAAAAAAAHjdgKlOOs895SI3KVwugAiqVkub4ETMJ0q1JOT/OwpM7Slq7ki0oWYqxZD0AAAAAAAAAAAAAAAAAAAAAAAAirO+Xf1ESMqcbfnYuAiAUr57gIK2I3LtZWbJ0gXIqlNThq5vaWiNISUYZ6z7CYjzE5ZAAAAAAAAAAAAAAAAAAAAADxsBcDB1or2o96K80eqeWfRgq0N84/aRHPX1Ty29EVXExlLV14pe07rPkiJvWemzlt6PcRiopWjKPY1khbJWI6SmKT6IKVrXbVusrHrKJZ0698oRvz2ItFt9kaWYUd8s34Foj1ExZAAAAAAAAAAAAAAAAAAAKtfHwjz3ZbL8L7+wytlrVeKTLXVtNPckvH89xz24qfJpGKFWelaj2N/nqsZTnvK/JEIZYuo9vjn/Uys5L+adQ8WJa2uK+wvkV8XXeY+S3Jae2/m9/8A04rbOH2oj2vHH90fFPs2Sf7Z+DJaWh/Fj9tD23H+ePieyZfyz8GWE0xT9K9VPN+0i9eMxedo+Ks8Ll/LPwXVjqbzurdaZtGfHPXbKcV46aRxxlGb9KUbLYrbebsIz4ZnrKZxZI8pXI1KD2OC7EvkaxbFPbTP+pCWFOL9WfdJ/Jl4rWe0o5p82Xm5rZN+HzTHLaO0nNHo88/NbdV9jXir/AjntHc1WUkcUvaTjzea+0vmWjJHmcnosGigAAAAAAAAAAAAACHGO0JPhFvwK3/DK1e8NNpjCP14qTjGPqRV5JJbIx33OTPimZ5q/BtitEzyz8Z7OMr9IvWVKMIzi84VP2luKg7K/Jnlzlv2iup9/wBaezj4GnSbzuPWvb+WnrdM6qUlmpL3ktbu9VdxlNs3aZdtPs/BPWOv18WnqdJq8vXqzfJS1V4C1LW83XXhsVe1YQrTMm89X6zkzKeGj9WkUhJHTdtuo+pP7iPZt+SJos0ukdPfT8WiJ4WfRWcM+qejp+ld/q1nn634kTw867KTgt6ttU6QQVC61M3ba+X8xrq3JrTkjhpnL3apaag91NdbqL5sx8Hferr8GY85+Tx6XXsZfRm/miYwa7RMJ8L83zhnS0xX9l1+xORpWt47TLO2DBPeKrdDpbioP9pKy2qUYq3YaRnz0nUWlnP2dw14/D8F/B+Uyayqeba/m9HxvY6Y43iq94izkyfY+H+2Zh2XRnTKxSdSMJQhvbX6uX0Je0d3C5LX3a1eWPf2ePxfDxhmKxaJn3d/3bjRWJjOMtT1YzcV2JXtyu2dWG0Wruvbyc2Ss1nU9101ZgAAAAAAAAAAAAY1IXTXFNd5EkKmGlrU4PjGPfYp1msLT0mUOO0dTqq1WnCouE4xn/VmisxPaVq3ms7r0+TnMb5OsBUd/wBH1Hxp1asP7t3HwKeFH5YdNeOzV7Wn99S0+kujSw84xp1sQ7pWhOUHH0m1Fpxim2tWWV+e5nJnx1p2h04uLyXiebX666otKeTXzj1oV9R706Mmr8bqRb2asdt/Brh+18lI1aIn92qn5Lq+7E0H1wqR+8rPD+/6+Dqj7ar50n4oJeTLFbq2Ff16i/yFfAn1j6/ZpH2zi86z8v5eLyZ4v+LhP+pP/wAB7PPrHxT/APYw/lt8I/lPDyfY1K3nsLb6c/8A1lZ4XfTcKT9rYd7itvl/L2Pk+xntYjCr7b/7ZHslfOY+aZ+2MflSfk9/3d1X62LofVpSl9xPg4o/u/yr/wDXnyx/NnHyf224y30aLT7P1nyI1hjzlS32lmt2pH+Xq6IYWP7Sti63Jy1I9yV/EznisVe1dq+JxF+u4j9v5bLRujcNR/4fB01L3pp1JfaqN27DP23JP4KxClsczH9S86+EfCHTYR1HFyqz1nqtpLYkllY0ra9qza87cl4pForSNKnRjTbVFU4Q1p69Vt2cttSVnqrK1tXNtHVw+fkxVpEdWfE4ubJNp7N1DHVr+tC/C0fh5y5rHEW+tfyw8Ov1/wCLeH0lmo1I6rdkpL1bvYnfON9258WdFM0T0lnbH5w2JszAAAAAAAAAAABSwGUXH3ZzXZrOUf7skUp20m3dYLqgHM4uSqaQhHdCLvwul/8ATw5nHl+9miHTTpimXSyOueznhFZ8TLU+crbYPrK9PVKOSRlK0MHSXArqE80sHhY8+9lJx1W8SzB4WPu362UnHHlC0ZJ9UGJVlayXUZ36eTSnWd7czVldt82eVM7nb1YjUaY4GLlNa17X6r79m0nHG7REmWeWs67t7pDEKnhqlR5ejZHo5J1in39Hn4682asfu0nRPD1a9ONGlLzcIxi8RVSvJzklLzUL5Xs83uyydzo4bDN/0/yrxNq1tM+fk7BdGsPa2pK/va89a/Hadvs+PWtOPxr7UnhpUp+Zm9eE0/NuW3nCXh3p7jmtjnHbXk15ovG/Nt9EYjXhZttwerd7WrJxb56rV+dzrxX5qsL11K8aqAAAAAAAAAABRj6Naa9+MZrrXoS8FDvKR0tMLT+GE1KW7gKTvoiYS6pdVylNtaQqcLJLrecn8F9U4ck6zuqP+J080dsuaDzNyJrtO2MqViOWDaGaOfJ3Xh5YokIGLZWUtPpOrk+eXZ/ocWa3SXbgr1hzdeuo7e7eebMxD061m3ZZ0bPWtLk/HL5muHrO2WeNRpb6XUtenRwt2vP1IwbW1Rk9VtX3q9+w9C9ea+PH79/Bx8Nbl58vpHR2GjNH08PSjSpR1YRWS2tva23vbd23zParWKxqHmWtNp3K0Sq1mmYpulxU2+6nP8Dn4n8MfXk1xeat0bqXdTht/wASql4JFOEncT9ecr541r68obw63OAAAAAAAAAAFLSXouFT3ZWl9Cdovueq+wzv01ZavXcMpO0ikzy3O8LEGbqOR0pUVLHLPOWq+qMlPb9aL70cHERrJt14+uN1cth3S5UsWSPKmwiRSkcuT8TSHhRLxkSIMTLLrMsk9GlI6tFpSp9y+ZwZ56PQwVcrXTnUaXG3cedPWXq1+7Tq6fQOEzXBZ9i2eJ6PCY9y8ri8vSWVF+f0pTW2NCE6j4a1tSKfXrt/VOzhI8TibX8qxphl/p8LFfO0u2PXeaNgc9pLG3vUWzVcafO7zn1NpW5JveebxWbpuP2deDHu0R8VnovhtSjrP27NfQSsu/N/WOjg8c0xRtTib8+SZbg6nOAAAAAAAAAAGFekpxlGWySafU1ZkTG41KYnU7anAYhyjKEv2lKThP8Ayy6pKz7XwOeese+F5jU/q2NCZrjtuFLQ4jTsLY6cnb0nSs081CMXlLh6TfX2M4+Kn7zsw/8AG7PCVdanF8kdmO26RLkvGrSnoy3F4VZz2EilI4792kPCqXjKyKWkKlvzvZhllvhrty2mMTbsyXXvPL4i/V63D02qaKwu97X8PxM8VNy1z5NdHW02qFFyeTav4HqTMYcW3kanNliqDyfYRunUxUtuIleH9jG6h2OTnJcpRO7gMM48Mb7z1Z8dki2TljtHR1FevGCvJpLnx4Li+R2TaIjcuSImezRaT0onlK6j/D9uf9p7seW17+B53E8ZSv3fl5/u68PDWt1j4+SDAYOeJlr1Falw95cI8uL7EU4fBbLPiZO3lC2XJXFHJTv6uoSPVcIAAAAAAAAAAAAHP6eX6PUji16llDEf2d/QqP6DbvybMckanm+LWn3o5fg4XSWnKlKlWxar10tepOCjUdvNuo1RSjJOKTi4bt54vtea3EeHjt03qOkeXd6+Pg8XhRa8ddORXT6nVcXLziquNNzqZNyqOUXNKNrej6Tvv2JZnfkw5IiZ3thjitrRXXR3lfpLicJQqVHKlVjTi5asoSg3bcpRlv6jh4X7StNq4+XvPr/00zfZ9dTaJdto/SUKsIzi8mk+o9THxVLxuHmZMF6TqV6Va6OjmjTLSuck92gQMWyJHO6Zxtk2trerD6T39Ss31I4sl+8y9DFTpEObqR15qO1R283v7WeXb71nq1+5TbpdEYO7XBZv7j0eHxPL4jL0a3pNj4160cIm9TJ13F2apZ+inulNq3FK7LWyUteLX/DHzThx3pSZrH3p+Tdy6QNRUaUYxjFJJRWtaKVkk3ZR7mb3+1K9qRtjXgLd7Sp01XryvHWb969/8R+jHqj3HPEcVxM+kfXn/DX/APPh98/Xl/LcaO6Nxj6VV6z91X1b83tl8OR38P8AZ+PF1t1ly5uMvfpHSG9SPQcb0AAAAAAAAAA8lJLaBG6vBdry/EjYgq17bZX5Ry8TO14jzWisy5bphidaFOlZfrKicltepTTm733aygu087j88xhtrpvp9fs7+CxbyxPopac0HSlQ83VlfziWtFbbZNavU1v4Hkcngct4nq9HHntltasR0cfofydYOnXhKdStOKkvRcYxXK7Td13HZb7Ttk+5PTavgTSJtWI3+7o+mGBjKNanrasbXva6jZKWa3rI4LT4XERyx5/5bYLTbFFp+tKfkqxs5UIqT2XX1VNxSfHI9LpXiLRHbpPxcvF03jiZfSlE79aeQ9JHjIkUdIYq0Wr9vLec+S/lDfFj3O5cdjsU29az3qmt9t8muLt3JczzM+X+2HrYMXnKzofBvLLNvx/AYMcyjicsLOndLuilhcNaeIms+EI75ze5fE9CeleWP3lw0rzT4l+3lChorRPm1nJOUnrTk85Sm9sm38LZJI5vDi09W1s866N/haFNWyjJ/wAz1u5bu47cVMde0Q4smS895ltqekmtqduq67tp2RmmO7n5Nr1DHRl+fltNa5ayrNZhZjJPNZmqr0AAAAAAAAB5KVld7gKzeWtLr6l9/MpM9NylWr1na3HN9uxGF7zrTWtY7tdXnfZJLqkjlvO+0/NtWPc5nGNPFZu6pQV3xdSV5eFOP2jy+MmI5azPnufr4vS4SJ5bTCbGV3OTk/zy6jiyX57bdeLHyV0ipPNda+JSveF7dpajpvjkqFaXv2j2Syl4ax04I8XiIn9/r91aV5KRWfr6hF0Bl5tRi9trPrdm/G50Tf8Ar79WXEV3i+b6lRneKfI9es7iJeBaNTplKVhMoiFTE4pJfnMxvkbUx7lz+kMTfLb8Oo4MuXyh6OLF6tbhsM3Jyk18kjmx45tZ05MkVrqEOkOlEYXoYO1Ss1aVT93TXXv7NvgelFYx1cMVm881uylo3D+a1pOcnUm71J7ZSffkluW4xm/Mtadr6xcl7V+tFdq8sMsPipXyu1vTzduTJiSYhvsLiNz2bjqxZJ7S5b09F+MW3lc6mC28RKklOWS1oxmuKm1FS+km11rsN63mI3Kut9G4OhmAAAAAAAAYzjdNcVYiY2Ku1ajykl381yKTG45fNMdJ2r1aXLPhy+ZhajWLNVi8JbOPajiyYtdYdFb76S5TBz19ep/EqSa+hH0Id8Yp9p4/FW3k16dPr93s8PXlxwsnM2EBynSR+erYehaTU612oq7cIRSlZLblOp3HqfZ1Os2+vX/UMuJty45/T5z0b9Kj5xToTjPO04P0Kq56rs29u7ezbNw29Wq4cXETFZrf/p2GE0hGNNXfemrdeRtjvy16uTJj5rdFfE6dgltv1RlYrbMtTA0GktPvPVj2yaj/AKIwmZv0ddccVcnpTpfKntdGPa5s1x8FFvVNsunO1tKY3HehRVRwe2T9GHZFZHZyYcEfe+EMt2t1j4y6no9oCeHp2kpNt3k7PNnn5sniW3ro05oiNb6t3ChJ7It9hnqWe4TT0NWlZZQW9vOXUkaRitKIy0jv1bbB6HlH1VJ5WuzSMFvJjbNE920wmiZXvLKxvj4ed7ljfL01Db2jTi22oxW2Tdl2s64qw219GX6XOOon+j05azk1bzs4+qor3U87lqxzz07R80z93v3dCdLIA8bAJgegAAAABhVpKSzXVxT5MiYiRVqUprhNc8pfcykxb9UxppukeOVOhUdpRqOOpTUl+8n6EM+GtJPsOfNetaTafKNtsVZteKx5uXo0lCMYrZFJLqSsfJzMzO5fTa10ZsgeSlaMpe7Fvttl4tFqRuUT11HrLldHaUhQ0rByhOfmqUklBJtVJZ6zu1ZWqvPqPZ4GOTDzev8A5/py8f8Afrr3/wCI/wC3cY+lHHRvPBa38zi1NfWizr5r2663+zyq/wBPtZqo9Dpr9nWrUlw18l2FfvecNPFhRxfQXFz/AOZTa4S1CdxH9kfE8VUj5LJS/aY6b6pRj/lZaMto7VhE5PWZbfRfkwwdJ3ajN8ZOU3f4eBFpy372+CPFiO0OwwWhKMFaMXbgotLwRWvDV89yzvntK7HR1P8Ahvtv82bRw8flZzlt6rVLDW2RUe5fA1rgmO0aZzfbycoQ9acI9qRbkrXvJuZ7Q1mL6TYSntq6z4R9J/cRN8VfetFLy1VXpg6j1KEIxvknUu32Qj+JXxbW/DHxRyxHeU8NGOclPEVJVZLNReUE+UCfD3O7Ts5/y9G6hjZJWVrLYrbuw25pUZ/p8uXcOaR5GvUnkn3ZeI3Mi1Qwls5ZvwLRVC0WAAAAAAAADjumuJ161Ggs9ROtP6TvCkn31H9VHkfa+XWOMcd7T8o+oen9m4/vTknyaZo+de1t4Aqx/Vv+acI9ieu/6PEvE6paUf3x+8/6/wBvkdXTk6eOqYhRvGbnHWabjq6yatblGJ9Lhwa4eKecPNz5Kzk1afqer6l0f8obnCyVJW22cfhe5Xxs2PppzX4bHPWJb5dNcrvzX2rE+2ZPysvZa+p/tzHjR+2ifbL/AJT2WPVFV6fwjtlS+1cn2vJ+UjhPeo1vKbTXtx7Ff4oj2rNPaq/sUeqnV8qUd0r9UUPG4ie0HsuOO9muxPlNqv1FPtSiN8RPno5OHr3nbWz6a4qo89drgpP5IeDefxXlSc2Kv4K/F5F43FO0YNLlFvv/ABLVwUhlOe0um0R0Nqba1S3JKN/DJeJrXHEM5tM93WYHR1OirU4JcXtk+ts0iNKraQFmGAk+C6y3LJtnDRz3tdhPKL1KmoqyLRGkMyQAAAAAAAAAcDpTReOVetWVFT15tpwnCVqcY6kFaTi09VXaV85M8bjeBz5sviVmNa1H1p63CcVgx4+S2/eo4nSVeP7fB1FfbJQqR72oOF+04snC54/FT4a/066ZOHn8GTXulBR0lRnsqWfBuF/CV/A4r4uXvuP1jTpi0z21P6Sj03jfNYapU9yMpJ/zWsvzzIw18S9ae8t93dvc4jQPQqtilBKE7JLdZK+buz6yJnyfNZr895s+iaJ8l9CEbVYub4X1Y3+LLcss96bCfk0wbX7CK6pNE8krc9vVSr9AMBHJ0JX4Kcvkyswc9vVXfk9wr9XC2+lOUvBDUnPb1ZUPJxSX7peP3DlsibTPdep9AsOttJv6rHJKE0OheHX7qXYrfBXHINhhujlKPq0F2pv+onk9w2dLAS2KKiuxeCLcsizT0evad+rInlQnjhIL2V25luWBJGmlsSXYToZAAAAAAAAAAAAAAAAK2KwFKqrVKVOa4ThGS8UExMx2auv0PwM1Z4WilleMY6kXZ3V4xsmst6M/Bx73yxv9Gnj5Na5p1+rdUqairRSilsSSS7kaRDJmAaAwVOK2JdyI0MyQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/Z",
          alt: "tea",
        },
        { type: "operator" as const, content: ") + I" },
      ],
    },
    {
      answer: "HOSTAGES",
      clues: [
        {
          type: "image" as const,
          content:
            "https://media.istockphoto.com/id/181885057/vector/comic-image-of-an-announcer-making-a-speech.jpg?s=612x612&w=0&k=20&c=IVwzYJC4WCjsHExR0Vv5J-SFeRPr-m7g0W-0bNfcvsY=",
          alt: "Host",
        },
        { type: "operator" as const, content: "+" },
        { type: "operator" as const, content: "(" },
        {
          type: "image" as const,
          content:
            "https://img.freepik.com/premium-vector/empty-theater-stage-with-red-velvet-curtains-3d-illustration_1249410-76714.jpg?semt=ais_hybrid&w=740&q=80",
          alt: "Stage",
        },
        { type: "operator" as const, content: "- ST) +" },
        {
          type: "image" as const,
          content:
            "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUQExIWFRUXFRcWFxUVFRUWFRUVFRUXGBcWGBUYHSggGBolHhUVIT0iJikrMS4uFx81ODMsNygtLisBCgoKDQ0ODw8PFTcZFRkrLS0rKzc3LSsrKysrLS0rKysrKystKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAL8BCAMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABgcFCAEDBAL/xABEEAABAwICBwQHBQUHBQEAAAABAAIDBBEGIQUHEjFBUWETInGBMkJSYnKRsRQjQ6GiU4KSssEIM2Nzg8LRJETD4fAV/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAFhEBAQEAAAAAAAAAAAAAAAAAABEB/9oADAMBAAIRAxEAPwC8EREBERAREQEREBERAREQEREBERAREQEREBERAREQERVvjfWtFRyupoIhPK3J5LtmNjvZuAS53ggshFXWBtacVbKKaaLsJXegQ7bjebXLQSAQ63BWKgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiKN46xbFo6nMrrOkd3Yor2L39eTRvJQYbWpjcUMPYwu/wCplHd/wmbjIevAdfBa7ucSSSSSSSSTckk3JJ4knNenSukZaiZ9RM/bkebuP0AHADcAvKishh0kVdNs5H7TBu/zWg/kT81tstVMEw7ekKRvOpi/J4J+i2rRBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERARFi8R6egooHVE7tlo3D1nu4NaOJKDrxViKGhgdUTHdk1g9KR3Brev0C1mxPiCeuqHVMxzOTWj0Y2cGNH1PEr0YwxTNpCczy5NGUcQN2xt4Dq47yVgkURSGjwtIaCfSct2xM2WxDjLI+RjL/ANo58VHkVK9VdPt6VpRye55/cjefrZbNrXnUdTbWk9rgyCR3mSxo/mK2GRkREQEREBERAREQEREBERAREQEREBERAREQEREBERARFgsXYpg0fCZpjcm4jjHpyO9lo/rwQejEuIIKKA1E7rAZNaPSe7g1o4la2YxxVPpCczSmzRcRxA92Np4dXcyurFWJp6+YzzHdkyMehE3k0f14rDIop3qywC6vkE8wLaVhz3gzOHqNPs8z5DjbjVrq/fXvE8oLKVrszuMxBzYzpzd5LYakpWRMbHG0MY0BrWtFg0DgAgrjXlKyLRsVO0BofPG1rRkA2Nrn2A5Xa1UMre/tB1vfpKfk2WQ+JLGt+j1UKC2v7PlLeWqm4NZGwHq5znH+UK7FWOoKi2aGWY/iVBt8MbGtt/FtqzkQREQEREBERAREQEREBERAREQEREBERAREQEREBEVeaxNZUdGDT05ElTuPFkOW93tO935oMxjvHEGjo8/vJ3D7uEHM+88+qzr8lrpp7TU9ZMaid+087uDWj2Wj1WrzV1ZJNI6aV5fI83c9xuSf+Oi6EWCsDVrq7fWuFTOC2lBy4OnI3hvJnN3HcFkNWmrI1GzV1jS2HeyFwIdLyLxvDOnFXpGwNAa0AAAAACwAGQAHAIPilpmRsbGxoaxoDWtaLBoG4ALtRcONhc7kRrnrnr+10pI0G4ijji8DYvd+cn5KDBe/EFf29VPUftJXuHwlx2f02XjhpzI5sQ3vc1g8XkNH5lFbM6rqLstF0rbWLo+1PjKS//cpUumipxHGyMbmMa0eDQAPou5EEREBERAREQEREBERAREQEREBERAREQEREBfMkgaC4kAAXJJsABxJ4Lwac01BSRGaeQMYOe9x9lo4noqAx7rFnryYmXhpuEYPek6yn/aMvFBKNYetcu2qWgdYZh9SOPuxdPf8AlzVQuN8zmTvJzJ6kneUXq0Xo6WolbBCwySONg1v1J4DqUV5mNJIABJJAAAuSTuAA3lXRq31WhmzV1zbvFnR053MPB0ntO93cOqz+rzVvFQgTzbMtV7XqRdIwePvfRT5ACIiIKPawdKfZtHVMwNndmWM+OTuN/NwUhVTa/wDS2zDT0gOcjzK4e5GNlt/Fz/09EFIgWUt1WaN7fSdM212xuMzv9IbTf17Ciat/+z9ovvVNWRuDYWn9brfpRVzoiIgiIgIiICIiAiIgIiICIiAiIgIiICIuuonaxpe9wa1ouXONgAOJJQdhUNx1rBp9HtLBaWoI7sLT6N9zpD6jfzUIx3rdLtqn0ebNzBqSMzw+6ad3xHyCqSSQuJc4lxJJJJJJJ4knMorJ4jxFU1svbVEm0fVaMmMHJreHjvPFYpcFWPgDVdNV7NRVB0NPkWt3SyjoPUb1OZ4DigjGEcI1OkJNiFtmA9+ZwPZsB/md7o58FsPhDCFNo+Ls4m3eR35XAbch6ngPdGSy2jdHxQRthhjbGxuQa0WA/wCT1XqRBERAREQFrPrW0z9p0lMQbsitAzjlHfaPm9z/AJBX7jPTYo6Kap4tYQwc5Hd1g+ZC1Vc4kkk3JzJ5k5kouOFs1qt0R9m0bA0iz3jtn333k7wB8G7I8lr5hPQ5q6yClAyfINr/AC296T9IPzC2uY0AAAWAyA5AIa5RERBERAREQEREBERAREQEREBERARdVTUMjaZJHtYxou5znBrWjmScgFUONtb4zg0fnwNQ4Zf6TTv+I5bt6Cf4wxpS6PZeV+1IR3YWWMjuWXqt945Kg8ZY3qtIOtI7YhB7sDCdgdXH1z45KPVVS+R7pJHOe9xu57iS5x6krqRRenRujpZ5Gwwxukkdua0XPifZHU5KR4JwDVaQO2AYoL5zuGR5iMeueu7qr/wthWmoI+zgZYn03nN7zzc7+iCH4B1VxU2zUVezLPvazfFEel/Td1PkrLREQREQEREBEWNxFpiOkppKqQ92NpNuLneq0cyTYIKk184h2pY9HsOUf3stj67hZjPJt3fvNVTL06TrnzzSTyG75Hl7uhdw8ALDyXXSUz5XsijG097gxo5ucbBFW3qD0DnNXuH+DH+TpHD9LfJXMsXhjQzKOlipWbo2AE+07e53mSVlEQREQEXy94AJJAAzJJsAOd1XWLNblJT3jprVUu67TaFp6yet+7dBYVVUMjYZHuaxrRcucQ1oHMk5BebQ2l4KqIT08gkjJc3aG67TYrWHEuKquuftVEpLb3bG3uxM8Gc+puVKtTWK/stV9lkdaGoIAJ3Mm3NPQO9Hx2UGwSIEQEREBERARFisQ4ipqKPtaiVrB6o3veeTWb3FBlVDMYayKOhJjuZpx+FGQdk++69m+G/oqwxnrWqaraipgaeE5Eg/fPHVw9AHkM+qrsosSHFuMqvSDrzPtGDdsLLiNvI29Y9So8iy8mGattKa58JZBtNaHOyLtvIOa3fs3sLm29BiFaeqLAtLWMNZUOMmxIWCDcwEAG7+LxY7t3O6qxWtqD0wGTzUbjYStErPjjycPNpH8BQXdHGGgNaAABYACwAHAAbgvpERBERAREQEREBa/a4cZCrm+yQu+5hcdojdJKLgkcw3MeN1MdbmPRAx1DTv+/eLSPaf7lh3i/tkfLeqJRcFa2o7CxklOkZB3I7shB4yHJzx8IJHi4qvcMaCkrallNHvce87gxg9J58AfmtptEaNjp4Y6eIbLI2hrR4cT1JzQ17EXl0jpGKBhlmkZGwes9waPz4qs8Ta5YGAso4jM79o+7Ih1DfSf+SItOaVrWlznBrQLkkgADqTuVd4k1v0cF2U4NS8X7ze7CD/AJh9L90FUxiLFFXWuvUzOeL3EY7sTfBgy8zcrDosSPFONayuJE0lo+ELLtj8x63711HFwSpnhTVvW1lnlnYQnPtJQQXDmxnpO8TYIIap5hTVZW1WzLIPs0eRDng9qeILI94PEF1vNW5hPV3RUNntZ2sw/GlAc4HmwbmeWfVS5CuqliLGNYXFxa0NLnW2nEC1zbK5RdqIgiL5kkDQXOIAGZJNgBzJQfS89dWxwsMkr2sYN7nkNA8yq8xfrdpoLxUg+0SjLazELT8Xr+Ay6qmsQ4kqq1+3UzF/ss9GNnwsGQ8d/VBaGMNcbReKgbtHd28gOyPgZ63icuiqLSOkJZ5DNNI6SQ73PNzbkOQ6DJeZdlPA57hGxrnvcbBrRdxPQBFdaymH8PVNZJ2VPGXni7cxnVz9w+vRWJg7U69+zLXuMbd/YRnvno9/qeDc+quPRejIaeMQwRtjY3c1gsP/AGeqFQXBWqmnpdmaptUTjMAt+6jPusPpHqfkFMcTaIbVUk1KfxIy0dHb2nyICyiIjT2ogcxzo3iz2uLXA7w5psR8wu/RGkJKeeOpiNnxPD28jbIg9CCR5qytduETHL/+jE37uSwmA9STcH+DsgTzA5qqkVtlhrTsVbTsqYjk4Zt4sd6zHdQVlFqvhHFlRo+XtITdrrdpE70JAN1/ZcOYV64b1maPqgAZRBId7Jjs5+6/0XBETNF8RStcLtcHDmCCPmF9oCLy1mkYYgXSysjAzu97W/UqG6c1s6OgBEb3VD/ZiHdv1kdZoQTslVhrF1oMgDqajcHz+i+UWLIeduDn/kFX+LNZtbWgxtP2eE5GOInacPfkyJ8Bs+ahIRY+5ZXOJc4lznEuc5xJJccySTvN0ghc9wYxpc5xAa1ouSTkAF8L6jkLTdpIPMGx+aKuzCk+jtBwH7RUMfWSAGVkX3j2jhE0N3AHibXNysJiLXRUSXZSQthb+0ktJJ4hvot/UqrAXKI9WktJTVD+1nlfK/2pHF1r79kHJo6Cy8q7aWmfI4Rxsc953NY0ucfIZqwsN6oKyez6hzaZnIjblI+EGzT4k+CCuPruA5k8uammF9WdfV2eWfZ4j+JMDtEc2xDvHzsrqwzgGgorOiiDpP20tnyeRtZv7oClCCG4V1a0NFZ+x28w/Fms4g+4z0WeQv1UyREQREQEREHBWs+P8Q6QmqJaarlsI3lnYx3ZDluOze77ixu4nfwWzKprXzhsDs9JMHKKb/xvP8vm1BTyW/8AuvLqVLcJ6vK6us5sfZQn8WUFoI9xnpO/IdVdOEdXVHQ2eG9tNxllAJB9xu5n16otVJhDVbWVZD5QaaH2ntvI4e5Hw8XW8Crswtg+koG2gjG0fSld3pHeLjuHQWCz6IgiIgIiIOmtpGSsdFI0PY8FrmnMFp3ha8aw9Xk1A900QdJSk3Dxcuiv6sgGdve+ee/Y1cPYCCCAQd4OYPkg06RX7inVDS1BMtM77NIbnZA2oSfguNny+SrTS+q/SkByg7ZvtQva79DrO+QRaiUFTIz0JHs+B7m/ykLudpWpORqZyORnlI+RcvivoZYHbE0T4nEXDZGlhI5gO3jqvOijzc3OZ5nM/Mollw423lByi9VFo2eawihkkv7EbnfmBYKUaL1XaUm304hHOeRrfPZbtO+YRENQq6ND6kWCxqqpzubIWhg8Nt9z8gFPdB4I0fSWMNMzaA9N47ST+N1yPJCtfNBYG0hV2MVM4MP4kv3TPm7M+QKsjD2pSNtn1lQZD+zhGwzwLz3neWyrcRBjtDaDpqVuxTwMiHHZbYnxdvPmsiiIgiIgIiICIiAiIgLrnha8bL2hzTbJwBGRuMj1C7EQAEREBERAREQEREBERAREQeWu0dDMLSxRyDk9jXfULBy6v9FuNzQwj4W7P8tlJkQRdmrzRQ/7GE+ILh8iVkqPDFDF/d0kDPhiYD87LLIg4a0DICw6ZLlEQEREBERAREQEREBERAREQEREH//Z",
          alt: "s",
        },
      ],
    },
    {
      answer: "FREED",
      clues: [
        {
          type: "image" as const,
          content:
            "https://media.istockphoto.com/id/1413056339/vector/red-free-stamp.jpg?s=612x612&w=0&k=20&c=16ng4tPJkMoN4DuTy3fbNr_tepOAp-_w80aS3BfpdRA=",
          alt: "Free",
        },
        { type: "operator" as const, content: "+ D" },
      ],
    },
    {
      answer: "FROM",
      clues: [
        { type: "operator" as const, content: "(" },
        {
          type: "image" as const,
          content:
            "https://www.svgheart.com/wp-content/uploads/2024/07/afro-girl-curly-black-woman-min_426-430-min.png",
          alt: "Afro",
        },
        { type: "operator" as const, content: "- A ) + (" },
        {
          type: "image" as const,
          content:
            "https://www.svgrepo.com/show/500844/emdash.svg",
          alt: "em dash",
        },
        { type: "operator" as const, content: "-" },
        {
          type: "image" as const,
          content:
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTS9OcKpJEiMPufp7eCzz05BCVPBEOnGCcqjQ&s",
          alt: "dash",
        },
        { type: "operator" as const, content: ")" },
      ],
    },
    {
      answer: "GAZA",
      clues: [
        {
          type: "image" as const,
          content:
            "https://thumbs.dreamstime.com/b/bandage-icon-flat-style-illustration-vector-web-98894516.jpg",
          alt: "Gauze",
        },
        { type: "operator" as const, content: "+" },
        {
          type: "image" as const,
          content:
            "https://ih1.redbubble.net/image.752995130.0063/st,small,507x507-pad,600x600,f8f8f8.u4.jpg",
          alt: "A (sign language)",
        },
      ],
    },
  ],
  hints: [
    "First word: A type of test without 'qu' + a trail without tea + a homophone of see",
    "Second word: Someone who presents + a stage without the first two letters + S",
    "Third word: Not costing money + grade better than failing",
    "Fourth word: A common hairstyle without the first letter + letter M",
    "Fifth word: Gauze + sign language letter",
  ],
};

export default function App() {
  const [isTimerActive, setIsTimerActive] = useState(true);
  const [isPaused, setIsPaused] = useState(false);
  const [solveTime, setSolveTime] = useState(0);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [isPuzzleComplete, setIsPuzzleComplete] =
    useState(false);

  const handlePuzzleComplete = useCallback(() => {
    if (!isPuzzleComplete) {
      setIsTimerActive(false);
      setIsPuzzleComplete(true);
      setShowShareDialog(true);
    }
  }, [isPuzzleComplete]);

  const handleUseHint = () => {
    setHintsUsed((prev) =>
      Math.min(prev + 1, puzzleData.hints.length),
    );
  };

  const togglePause = () => {
    if (isPuzzleComplete) return;
    setIsPaused(!isPaused);
    setIsTimerActive(isPaused); // If currently paused, resume timer
  };

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-orange-50 via-yellow-50 to-pink-50 overflow-hidden">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm shadow-sm flex-shrink-0">
        <div className="max-w-5xl mx-auto px-4 py-2.5">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h1 className="text-primary mb-0.5">
                Decryptions
              </h1>
              <p className="text-xs text-muted-foreground">
                Decode the News, One Puzzle at a Time
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Timer
                isActive={isTimerActive && !isPaused}
                onTimeUpdate={setSolveTime}
              />
              <Button
                variant="outline"
                size="icon"
                onClick={togglePause}
                disabled={isPuzzleComplete}
                className="shrink-0"
              >
                {isPaused ? (
                  <Play className="w-4 h-4" />
                ) : (
                  <Pause className="w-4 h-4" />
                )}
              </Button>
              <InstructionsDialog />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="inline-block px-2.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs">
              {puzzleData.category}
            </div>
            <span className="text-xs text-muted-foreground">
              {puzzleData.date}
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden">
        <div className="max-w-5xl mx-auto px-4 py-6 min-h-full flex flex-col">
          <div className="mb-4 text-center">
            <h2 className="text-primary mb-0.5">
              Today's Headline
            </h2>
            <p className="text-xs text-muted-foreground">
              Solve the rebus puzzle to reveal the news!
            </p>
          </div>

          <div className="flex items-center justify-center mb-6">
            <RebusPuzzle
              words={puzzleData.words}
              onComplete={handlePuzzleComplete}
              isPaused={isPaused}
            />
          </div>

          {/* Controls */}
          <div className="flex flex-wrap items-center justify-center gap-2 mb-4">
            <HintDialog
              hints={puzzleData.hints}
              usedHints={hintsUsed}
              onUseHint={handleUseHint}
            />

            {isPuzzleComplete && (
              <Button
                onClick={() => setShowShareDialog(true)}
                className="gap-2 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
              >
                Share Results
              </Button>
            )}
          </div>

          {/* Success Message */}
          {isPuzzleComplete && (
            <div className="p-4 bg-white rounded-xl shadow-md text-center border-2 border-green-200 mb-4">
              <p className="text-2xl mb-1">🎉</p>
              <h3 className="text-green-700 mb-1">
                Congratulations!
              </h3>
              <p className="text-sm text-muted-foreground">
                You've decoded today's headline:{" "}
                <span className="text-primary">
                  "{puzzleData.headline}"
                </span>
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Pause Overlay */}
      {isPaused && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-white rounded-2xl p-8 shadow-2xl text-center max-w-sm mx-4">
            <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Pause className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-primary mb-2">Game Paused</h2>
            <p className="text-muted-foreground mb-6">
              Take a break! Click below when you're ready to
              continue.
            </p>
            <Button
              onClick={togglePause}
              size="lg"
              className="w-full gap-2 bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
            >
              <Play className="w-5 h-5" />
              Resume Game
            </Button>
          </div>
        </div>
      )}

      <ShareDialog
        isOpen={showShareDialog}
        onOpenChange={setShowShareDialog}
        solveTime={solveTime}
        hintsUsed={hintsUsed}
        headline={puzzleData.headline}
      />

      <Toaster richColors position="top-center" />
    </div>
  );
}